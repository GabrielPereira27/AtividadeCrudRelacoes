
<form action="<?php echo e(route('editoras.update', ['id'=>$editora->id_editora])); ?>" method="post">
	<?php echo csrf_field(); ?>
	<?php echo method_field('patch'); ?>

	<b>Nome: </b><input type="text" name="Nome" value="<?php echo e($editora->Nome); ?>"><br><br>
	<b>Morada: </b><input type="text" name="Morada" value="<?php echo e($editora->Morada); ?>"><br><br>
	<b>Observacoes: </b><input type="text" name="Observacoes" value="<?php echo e($editora->Observacoes); ?>"><br><br>
	<input type="submit" value="Enviar">
</form>



<?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/editoras/edit.blade.php ENDPATH**/ ?>