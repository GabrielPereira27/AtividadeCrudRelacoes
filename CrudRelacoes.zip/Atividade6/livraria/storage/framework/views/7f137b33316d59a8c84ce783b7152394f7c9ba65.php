<form action="<?php echo e(route('autores.store')); ?>" method="post">
	<?php echo csrf_field(); ?>
	<b>Nome: </b><input type="text" name="Nome"><br><br>
	<b>Nacionalidade: </b><input type="text" name="Nacionalidade"><br><br>
	<b>Data Nascimento: </b><input type="date" name="Data_nascimento"><br><br>
	<input type="submit" value="Enviar">
</form>

<?php if( $errors-> has('Nome') ): ?>
<b>Deverá indicar um nome correto.<b><br>
<?php endif; ?>

<?php if( $errors-> has('Nacionalidade') ): ?>
<b>Deverá indicar uma nacionalidade correta.<b><br>
<?php endif; ?>

<?php if( $errors-> has('Data Nascimento') ): ?>
<b>Deverá indicar uma data nascimento correta. <b><br>
<?php endif; ?>
<?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/autores/create.blade.php ENDPATH**/ ?>