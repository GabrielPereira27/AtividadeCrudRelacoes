<form action="<?php echo e(route('editoras.store')); ?>" method="post">
	<?php echo csrf_field(); ?>
	<b>Nome: </b><input type="text" name="Nome"><br><br>
	<b>Morada: </b><input type="text" name="Morada"><br><br>
	<b>Observacoes: </b><input type="text" name="Observacoes"><br><br>
	<input type="submit" value="Enviar">
</form>

<?php if( $errors-> has('Nome') ): ?>
<b>Deverá indicar um nome correto.<b><br>
<?php endif; ?>

<?php if( $errors-> has('Morada') ): ?>
<b>Deverá indicar uma morada correta.<b><br>
<?php endif; ?>

<?php if( $errors-> has('Observacoes') ): ?>
<b>Deverá indicar uma observacao correta. <b><br>
<?php endif; ?>
<?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/editoras/create.blade.php ENDPATH**/ ?>