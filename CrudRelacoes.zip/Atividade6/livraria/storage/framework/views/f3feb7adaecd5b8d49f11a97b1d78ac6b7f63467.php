<?php $__currentLoopData = $genero->livros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $livro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h3><?php echo e($livro->titulo); ?></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Gabriel\PSI_\Atividade3\livraria\resources\views/generos/show.blade.php ENDPATH**/ ?>