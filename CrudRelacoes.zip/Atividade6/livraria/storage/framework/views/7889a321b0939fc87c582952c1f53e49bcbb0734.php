
<form action="<?php echo e(route('livros.update', ['id'=>$livro->id_livro])); ?>" method="post">
	<?php echo csrf_field(); ?>
	<?php echo method_field('patch'); ?>

	<b>Título: </b><input type="text" name="titulo" value="<?php echo e($livro->titulo); ?>"><br><br>
	<?php if( $errors-> has('titulo') ): ?>
	<b>Deverá indicar um Titulo correto. <b><br>
	<?php endif; ?>

	<b>Idioma: </b><input type="text" name="idioma" value="<?php echo e($livro->idioma); ?>"><br><br>
	<b>Total Páginas: </b><input type="text" name="total_paginas" value="<?php echo e(old('total_paginas')); ?>"><br><br>
	<b>Data Edição: </b><input type="date" name="data_edicao" value="<?php echo e($livro->data_edicao); ?>"><br><br>
	<b>ISBN: </b><input type="text" name="isbn" value="<?php echo e($livro->isbn); ?>" value=""><br><br>
	<?php if( $errors-> has('isbn') ): ?>
	<b>Deverá indicar um ISBN correto (13 carateres)<b><br>
	<?php endif; ?>

	<b>Observações: </b><textarea type="text" name="observacoes" value="<?php echo e($livro->observacoes); ?>"></textarea><br><br>
	<b>Imagem Capa: </b><input type="text" name="imagem_capa" value="<?php echo e($livro->imagem_capa); ?>"><br><br>
	<b>Gênero: </b><input type="text" name="id_genero" value="<?php echo e($livro->id_genero); ?>"><br><br>
	<b>Autor: </b><input type="text" name="id_autor" value="<?php echo e($livro->id_autor); ?>"><br><br>
	<b>Sinopse: </b><textarea type="text" name="sinopse"><?php echo e($livro->sinopse); ?></textarea><br>
	<input type="submit" value="Enviar">
</form>
	<select name="id_autor[]" multiple="multiple">
		<?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<option value="<?php echo e($autor->id_autor); ?>">
			<?php if(in_array($autor->id_autor, $autoresLivro)): ?> selected <?php endif; ?>
			<?php echo e($autor->nome); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select></section>














<?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/livros/edit.blade.php ENDPATH**/ ?>