ID:<?php echo e($autores->ida); ?><br>
Título:<?php echo e($autores->nome); ?><br>
Idioma:<?php echo e($autores->idioma); ?><?php /**PATH D:\PSI\Atividade-3\livraria\resources\views/autores/show.blade.php ENDPATH**/ ?>