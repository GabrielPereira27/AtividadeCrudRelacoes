<ul>
<?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li>
	<a href="<?php echo e(route('autores.show' , ['id' => $autor ->id_autor])); ?>">
	<?php echo e($autor->nome); ?>

	</a>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo e($autores->render()); ?><?php /**PATH D:\Gabriel\PSI\ProjetoM17\Atividade6\livraria\resources\views/autores/index.blade.php ENDPATH**/ ?>