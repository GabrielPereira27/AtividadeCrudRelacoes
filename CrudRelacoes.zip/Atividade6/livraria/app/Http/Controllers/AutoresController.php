<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Autor;

class AutoresController extends Controller
{
    //
    public function index(){
    	$autores = Autor::all();
    	 //   	$autores = Autor::all()->sortbydesc('ida');
    	$autores = Autor::paginate(4);

    	return view('autores.index', [
    	'autores' => $autores
    	]);
    }

    public function show (Request $request) {
    	$idAutor = $request->id;
    	$autores = Autor::findOrFail ($idAutor);

    	return view ('autores.show', [
    		'autores' => $autores
    	]);
    }

    public function create(){

        return view ('autores.create');
    }

     public function store(Request $request){

        $novoAutor = $request -> validate ([
        'nome' => ['required', 'min:3', 'max:100'],
        'nacionalidade' => ['nullable', 'min:3', 'max:20'],
        'data_nascimento' => ['nullable', 'numeric', 'min:1'],
        ]);

        $autor = Autor::create($novoAutor);
        return redirect()->route('autores.show', [
        'id'=>$autor->id_autor
        ]);
    }


    public function edit(Request $request) {

        $idAutor = $request->id;
        $autor = Autor::where('id_autor', $idAutor)->first();
        return view('autores.edit', [
            'autor'=>$autor
        ]);
    }

    public function update(Request $request) {
        $idAutor = $request->id;
        $autor = Autor::findOrFail($idLivro);
        $atualizarAutor = $request->validate([
            'nome' => ['required', 'min:3', 'max:100'],
            'nacionalidade' => ['nullable', 'min:3', 'max:20'],
            'data_nascimento' => ['nullable', 'numeric', 'min:1'],
            'data_edicao' => ['nullable', 'date'],
        ]);

        $autor -> update($atualizarAutor);

        return redirect()->route('autores.show', [
            'id'=>$autor->id_autor
        ]);
    }

    public function destroy (Request $request) {

        $idAutor = $request->id;
        $autor = Autor::findOrFail($idAutor);
        $autor->delete();
        return redirect()->route('autores.index')->with('mensagem', 'Livro eliminado!');

    }

    public function delete(Request $request){
        $idAutor = $request->id;
        $autor = Autor::where('id_autor', $idAutor)->first();
        return view('autores.delete', [
            'autor' => $autor
        ]);
    }
}
