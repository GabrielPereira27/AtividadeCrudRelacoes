<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Editora;

class EditorasController extends Controller
{
    //
    public function index(){
    	$editora = Editora::all();
    	//->sortbydesc('ide');
    $editora = Editora::paginate(4);

    	return view('editoras.index', [
    	'editoras' => $editora
    	]);
    }

    public function show (Request $request) {
    	$idEditora = $request->id;
    	$editora = Editora::findOrFail($idEditora);

    	return view ('editoras.show', [
    		'editoras' => $editora
    	]);
    }

    public function store(Request $request){

        $novoEditora = $request -> validate ([
        'Designacao' => ['required', 'min:3', 'max:100'],
        'observacoes' => ['nullable', 'min:3', 'max:20'],
        ]);

        $editora = Editora::create($novoEditora);
        return redirect()->route('editoras.show', [
        'id'=>$editora->id_editora
        ]);
    }

     public function create(){

        return view ('editoras.create');
    }

    public function edit(Request $request) {

        $idEditora = $request->id;
        $editora = Editora::where('id_editora', $idEditora)->first();
        return view('editoras.edit', [
            'editora'=>$editora
        ]);
    }

    public function update(Request $request) {
        $idEditora = $request->id;
        $editora = Editora::findOrFail($idEditora);
        $atualizarEditora = $request->validate([
            'Nome' => ['required', 'min:3', 'max:100'],
            'Morada' => ['nullable', 'min:3', 'max:20'],
            'Observacoes' => ['nullable', 'numeric', 'min:1'],
        ]);

        $editora -> update($atualizarEditora);

        return redirect()->route('editoras.show', [
            'id'=>$editora->id_editora
        ]);
    }

    public function destroy (Request $request) {

        $idEditora = $request->id;
        $editora = Editora::findOrFail($idEditora);
        $editora->delete();
        return redirect()->route('editoras.index')->with('mensagem', 'Livro eliminado!');

    }

    public function delete(Request $request){
        $idEditora = $request->id;
        $editora = Editora::where('id_editora', $idEditora)->first();
        return view('editoras.delete', [
            'editora' => $editora
        ]);
    }
}