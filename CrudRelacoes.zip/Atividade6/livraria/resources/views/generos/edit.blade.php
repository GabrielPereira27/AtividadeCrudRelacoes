
<form action="{{route('generos.update', ['id'=>$genero->id_genero])}}" method="post">
	@csrf
	@method('patch')

	<b>Designacao: </b><input type="text" name="Designacao" value="{{$genero->Designacao}}"><br><br>
	<b>Observacoes: </b><input type="text" name="Observacoes" value="{{$genero->Observacoes}}"><br><br>
	<input type="submit" value="Enviar">
</form>



