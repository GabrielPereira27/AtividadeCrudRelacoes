<form action="{{route('generos.store')}}" method="post">
	@csrf
	<b>Designacao: </b><input type="text" name="Designacao"><br><br>
	<b>Observacoes: </b><input type="text" name="Observacoes"><br><br>
	<input type="submit" value="Enviar">
</form>

@if ( $errors-> has('Designacao') )
<b>Deverá indicar uma Designacao correta<b><br>
@endif

@if ( $errors-> has('Observacoes') )
<b>Deverá indicar uma observacao correta. <b><br>
@endif

