ID Livro:{{$edicoes->id_livro}}<br>
ID Editora:{{$edicoes->id_editora}}<br>
Data:{{$edicoes->data}}<br>
Observacoes:{{$edicoes->observacoes}}