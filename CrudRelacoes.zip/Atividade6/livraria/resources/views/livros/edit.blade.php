
<form action="{{route('livros.update', ['id'=>$livro->id_livro])}}" method="post">
	@csrf
	@method('patch')

	<b>Título: </b><input type="text" name="titulo" value="{{$livro->titulo}}"><br><br>
	@if ( $errors-> has('titulo') )
	<b>Deverá indicar um Titulo correto. <b><br>
	@endif

	<b>Idioma: </b><input type="text" name="idioma" value="{{$livro->idioma}}"><br><br>
	<b>Total Páginas: </b><input type="text" name="total_paginas" value="{{old('total_paginas')}}"><br><br>
	<b>Data Edição: </b><input type="date" name="data_edicao" value="{{$livro->data_edicao}}"><br><br>
	<b>ISBN: </b><input type="text" name="isbn" value="{{$livro->isbn}}" value=""><br><br>
	@if ( $errors-> has('isbn') )
	<b>Deverá indicar um ISBN correto (13 carateres)<b><br>
	@endif

	<b>Observações: </b><textarea type="text" name="observacoes" value="{{$livro->observacoes}}"></textarea><br><br>
	<b>Imagem Capa: </b><input type="text" name="imagem_capa" value="{{$livro->imagem_capa}}"><br><br>
	<b>Gênero: </b><input type="text" name="id_genero" value="{{$livro->id_genero}}"><br><br>
	<b>Autor: </b><input type="text" name="id_autor" value="{{$livro->id_autor}}"><br><br>
	<b>Sinopse: </b><textarea type="text" name="sinopse">{{$livro->sinopse}}</textarea><br>
	<input type="submit" value="Enviar">
</form>
	<select name="id_autor[]" multiple="multiple">
		@foreach ($autores as $autor)
		<option value="{{$autor->id_autor}}">
			@if(in_array($autor->id_autor, $autoresLivro)) selected @endif
			{{$autor->nome}}</option>
		@endforeach
	</select></section>














