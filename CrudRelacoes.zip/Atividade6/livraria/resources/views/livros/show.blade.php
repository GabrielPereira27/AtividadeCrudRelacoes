<b>ID:{{$livro->id_livro}}</b><br>
<b>Título:{{$livro->titulo}}</b><br>
<b>Idioma:{{$livro->idioma}}</b><br>

@if(isset($livro->genero->designacao))
<b>{{$livro->genero->designacao}}</b>
@endif

@if(count($livro->autores)>0)

@foreach($livro->autores as $autor)
{{$autor->nome}}<br>
@endforeach

@else
<div class="alert alert-damage" role="alert">Sem autor definido</div>
@endif
<br>
	<br><a href="{{route('livros.edit' , ['id' => $livro ->id_livro])}}"><b>Editar</b></a>
	<br><a href="{{route('livros.create' , ['id' => $livro ->id_livro])}}"><b>Criar</b></a>
	<br><a href="{{route('livros.delete' , ['id' => $livro ->id_livro])}}"><b>Eliminar</b></a>